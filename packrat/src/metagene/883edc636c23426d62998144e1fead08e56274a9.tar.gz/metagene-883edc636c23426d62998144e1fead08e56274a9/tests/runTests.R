## Run all tests in the metagene package
BiocGenerics:::testPackage("metagene")
