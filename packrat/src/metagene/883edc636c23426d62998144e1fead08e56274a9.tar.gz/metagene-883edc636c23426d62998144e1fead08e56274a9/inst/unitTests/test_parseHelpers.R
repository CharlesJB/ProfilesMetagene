# Created by Astrid Deschenes
# 2014-07-28

## Test functions present in the parseHelpers.R file

### {{{ --- Test setup ---

if(FALSE) {
	library( "RUnit" )
	library( "metagene" )
}

### }}}

